/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.uacm.ces.proyectofinal.modelo;

import com.uacm.ces.proyectofinal.persistencia.Dao.IVendedorDao;
import com.uacm.ces.proyectofinal.persistencia.Dao.VendedorDaoImpl;
import java.util.Date;

/**
 *
 * @author the_m
 */
public class Vendedor {

    private int idVendedor;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String correoElectronico;
    private String userName;
    private String password;
    private Date fechaRegistro;
    private String estatus;

    public Vendedor(int idVendedor, String nombre, String apellidoPaterno, String apellidoMaterno, String correoElectronico, String userName, String password, Date fechaRegistro, String estatus) {
        this.idVendedor = idVendedor;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.correoElectronico = correoElectronico;
        this.userName = userName;
        this.password = password;
        this.fechaRegistro = fechaRegistro;
        this.estatus = estatus;
    }

    public Vendedor(int idVendedor, String nombre, String apellidoPaterno, String apellidoMaterno, String userName) {
        this.idVendedor = idVendedor;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.userName = userName;
    }

    public Vendedor() {

    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    @Override
    public String toString() {
        return "Vendedor{" + "idVendedor=" + idVendedor + ", nombre=" + nombre + ", apellidoPaterno=" + apellidoPaterno + ", apellidoMaterno=" + apellidoMaterno + ", correoElectronico=" + correoElectronico + ", userName=" + userName + ", password=" + password + ", fechaRegistro=" + fechaRegistro + ", estatus=" + estatus + '}';
    }

    public Vendedor obtenerVendedor(String user) {
        Vendedor vendedorEncontrado = null;
        IVendedorDao dao = new VendedorDaoImpl();
        vendedorEncontrado = dao.obtenerVendedor(user);
        return vendedorEncontrado;
    }
    
        public Vendedor obtenerVendedorId(int id) {
        Vendedor vendedorEncontrado = null;
        IVendedorDao dao = new VendedorDaoImpl();
        vendedorEncontrado = dao.obtenerVendedorId(id);
        return vendedorEncontrado;
    }

}
