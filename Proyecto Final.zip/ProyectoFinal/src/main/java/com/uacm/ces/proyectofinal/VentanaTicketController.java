/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.uacm.ces.proyectofinal;

import com.uacm.ces.proyectofinal.modelo.Pedido;
import com.uacm.ces.proyectofinal.modelo.PedidoProducto;
import com.uacm.ces.proyectofinal.modelo.Producto;
import com.uacm.ces.proyectofinal.modelo.Ticket;
import com.uacm.ces.proyectofinal.modelo.Vendedor;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class VentanaTicketController implements Initializable {

    @FXML
    private Text txtNombreFiscal;
    @FXML
    private Text txtRegimenFiscal;
    @FXML
    private Text txtDomicilioFiscal;
    @FXML
    private Text txtRFC;
    @FXML
    private Text txtLugarExpedicionTicket;
    @FXML
    private Text txtTipoCliente;
    @FXML
    private Text txtNombreVendedor;
    @FXML
    private Text txtVendedorCajero;

    private Ticket ticket;

    private ObservableList<PedidoProducto> objPedidoProducto;
    private ObservableList<Producto> objProducto;

    private List<PedidoProducto> PedidoProductos = new ArrayList<PedidoProducto>();
    @FXML
    private Text txtRFC1;
    @FXML
    private Text txtTipoCliente1;
    @FXML
    private Text txtTicketId;
    @FXML
    private Text txtTotalCompra;
    @FXML
    private Text txtCantidadProductos;

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Ticket ticket = new Ticket();
        ticket = ticket.obtenerTicket();
        Vendedor vendedor = new Vendedor();
        vendedor = vendedor.obtenerVendedorId(ticket.getVendedor().getIdVendedor());
        ticket.setVendedor(vendedor);
        txtNombreFiscal.setText(ticket.getNombreFiscal());
        txtRegimenFiscal.setText("601-General de ley personas morales");
        txtDomicilioFiscal.setText(ticket.getDomicilioFiscal());
        txtRFC.setText(ticket.getRfc());
        txtLugarExpedicionTicket.setText("Ciudad de Mexico");
        txtTipoCliente.setText("Persona Fisica");
        txtNombreVendedor.setText(ticket.getVendedor().getNombre() + " " + ticket.getVendedor().getApellidoPaterno());
        txtVendedorCajero.setText(ticket.getVendedor().getNombre() + " " + ticket.getVendedor().getApellidoPaterno());
        txtTicketId.setText(String.valueOf(ticket.getIdTicket()));
        ticket.getDomicilioFiscal();
        objPedidoProducto = FXCollections.observableArrayList();
        objProducto = FXCollections.observableArrayList();

        Pedido pedido = new Pedido();
        Pedido pedidoEn = pedido.buscarPedidoId(ticket.getPedido().getIdPedido());
        double total = pedidoEn.getTotalPagar();
        txtTotalCompra.setText(String.valueOf(total));
        PedidoProducto pedidoProducto = new PedidoProducto();
        List<PedidoProducto> PedidoProductos = new ArrayList<PedidoProducto>();
        PedidoProductos = pedidoProducto.obtenerTodosPedidoProducto(pedidoEn);
        int cantidadProductos = 0;
        for (PedidoProducto dc : PedidoProductos) {
            cantidadProductos = cantidadProductos + dc.getNumeroPiezas();
        }
        txtCantidadProductos.setText(String.valueOf(cantidadProductos));

        //System.out.println("this.ticket = " + this.ticket);
        //Pedido pedido = this.ticket.getPedido();
        //PedidoProducto pedidoProducto = new PedidoProducto();
        //PedidoProductos = pedidoProducto.obtenerTodosPedidoProducto(pedido);
        /*this.tableViewColumnNombreProducto.setCellValueFactory(new PropertyValueFactory("producto"));
        this.tableViewColumnImporte.setCellValueFactory(new PropertyValueFactory("subtotalPagar"));
        this.tableViewColumnCantidad.setCellValueFactory(new PropertyValueFactory("numeroPiezas"));
        this.tableViewColumnPrecio.setCellValueFactory(new PropertyValueFactory("numeroPiezas"));
        for (PedidoProducto pedidoPs : PedidoProductos) {
            Producto producto = new Producto();
            Producto pro = null;
            this.objPedidoProducto.add(pedidoPs);
            this.objProducto.add(pro);
        }*/
    }

    @FXML
    private void switchToVentanaPedido() throws IOException {
        App.setRoot("VentanaPedido");
    }

}
