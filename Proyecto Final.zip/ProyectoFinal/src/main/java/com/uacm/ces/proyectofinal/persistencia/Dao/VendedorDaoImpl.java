/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.uacm.ces.proyectofinal.persistencia.Dao;

import com.uacm.ces.proyectofinal.modelo.Producto;
import com.uacm.ces.proyectofinal.modelo.Vendedor;
import com.uacm.ces.proyectofinal.persistencia.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author the_m
 */
public class VendedorDaoImpl implements IVendedorDao {

    @Override
    public Vendedor obtenerVendedor(String pas) {
        Conexion conexion = new Conexion();
        String sql = "SELECT * FROM vendedor WHERE password = '" + pas + "';";
        Vendedor vendedor = new Vendedor();
        try {
            Connection conn = conexion.obtenerConecxion();
            Statement sentencia = conn.createStatement();
            ResultSet resultado = sentencia.executeQuery(sql);

            while (resultado.next()) {
                vendedor.setIdVendedor(resultado.getInt("idVendedor"));
                vendedor.setNombre(resultado.getString("nombreVendedor"));
                vendedor.setApellidoPaterno(resultado.getString("apellidoPaterno"));
                vendedor.setApellidoMaterno(resultado.getString("apellidoMaterno"));
                vendedor.setUserName(resultado.getString("username"));
            }

            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductoDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return vendedor;
    }

    @Override
    public Vendedor obtenerVendedorId(int id) {
        Conexion conexion = new Conexion();
        String sql = "SELECT * FROM vendedor WHERE idVendedor  = '" + id + "';";
        Vendedor vendedor = new Vendedor();
        try {
            Connection conn = conexion.obtenerConecxion();
            Statement sentencia = conn.createStatement();
            ResultSet resultado = sentencia.executeQuery(sql);

            while (resultado.next()) {
                vendedor.setIdVendedor(resultado.getInt("idVendedor"));
                vendedor.setNombre(resultado.getString("nombreVendedor"));
                vendedor.setApellidoPaterno(resultado.getString("apellidoPaterno"));
                vendedor.setApellidoMaterno(resultado.getString("apellidoMaterno"));
                vendedor.setUserName(resultado.getString("username"));
            }

            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductoDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return vendedor;
    }

}
